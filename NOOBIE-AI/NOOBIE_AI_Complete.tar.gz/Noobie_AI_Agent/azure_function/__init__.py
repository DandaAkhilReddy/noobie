"""
NOOBIE AI Azure Functions
========================

Serverless automation for daily blog generation and publishing.
This package contains the Azure Functions entry points.
"""

__version__ = "1.0.0"
__author__ = "NOOBIE AI Team"
__description__ = "Azure Functions for automated blog generation"